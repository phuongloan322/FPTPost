
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'phuongloan',
  applicationName: 'serverless-phuongloan',
  appUid: 'tKP7qM5LRXxMWG13Jb',
  orgUid: '48fa959c-a567-4d17-a601-a5b5d0c72e11',
  deploymentUid: '06c3ef5a-7c9b-4c7a-bad2-a6a4ba9e80fb',
  serviceName: 'serverless-phuongloan',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-phuongloan-dev-DeletePost', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/deletePost.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}